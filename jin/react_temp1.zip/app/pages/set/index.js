
import '@styles/set.less'
import userManage from './userManage'
import roleManage from './roleManage'
import moduleManage from './moduleManage'

export { userManage, roleManage, moduleManage }
