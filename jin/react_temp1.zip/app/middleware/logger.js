
/* eslint-disable */
export default store => next => (action) => {
  // console.log(action)
  return next(action)
}
