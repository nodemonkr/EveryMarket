
module.exports = {
  data: {
    totalCount: 100,
    currentPage: 1,
    pageSize: 10,
    'list|10': [
      {
        'id|+1': 1,
        'status|1': [1, 2, 3],
        'name|1': ['特朗普', '奥巴马', '老布什'],
      },
    ],
  },
  msg: '',
  errorCode: '',
  status: 1,
}
