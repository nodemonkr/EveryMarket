module.exports = {
  data: {
    ticket: 'ticket',
    token: '1111',
  },
  msg: '操作成功',
  status: 1,
}
