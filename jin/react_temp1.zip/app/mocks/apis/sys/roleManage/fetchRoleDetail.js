
module.exports = {
  data: {
    id: 2,
    roleName: '超级管理员',
    sort: 0,
    type: 0,
    resourceIds: [
      10060,
      10063,
      10062,
      10108,
      10109,
      10110,
    ],
  },
  msg: '操作成功',
  errorCode: '',
  status: 1,
}
