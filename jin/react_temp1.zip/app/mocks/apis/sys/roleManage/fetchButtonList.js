
module.exports = {
  data: {
    list: [
      {
        id: 134,
        resName: '新增附属区苑',
        resType: 3,
        parentId: 4,
        roleEntities: [],
        resKey: 'gardenAdd',
        sort: 0,
        status: 0,
      },
      {
        id: 137,
        resName: '新增附属区苑1',
        resType: 3,
        parentId: 4,
        roleEntities: [],
        resKey: 'gardenAdd',
        sort: 0,
        status: 0,
      },
    ],
  },
  msg: '操作成功',
  status: 1,
}
